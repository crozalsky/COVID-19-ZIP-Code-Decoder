print ("Mayor Data")

# Fremont mayor (Lily Mei) twitter feed: https://twitter.com/lilymei4fremont?lang=en
# City of Stamford twitter feed: https://twitter.com/CityofStamford?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor
# Salt Lake City mayor (Erin Mendenhall) twitter feed:on actual zip code page
# Anchorage mayor (Ethan Berkowitz) twitter feed: on actual zip code page
# New York City mayor (Bill de Blasio) twitter feed:on actual zip code page
# Cedar City mayor (Wilson Edwards) twitter feed:on actual zip code page
