print("Governor Data")

#CA governor (Gavin Newsom) twitter feed: https://twitter.com/GavinNewsom?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor
#CT governor (Ned Lamont) twitter feed: https://twitter.com/GovNedLamont?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor
#AK governor (Mike Dunleavy) twitter feed: 
#UT governor (Gary Herbert) twitter feed: 
#NY governor (Andrew Cuomo) twitter feed: 
