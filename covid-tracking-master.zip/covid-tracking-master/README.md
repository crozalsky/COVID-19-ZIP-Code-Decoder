# COVID-19 Zip Code Decoder

# The purpose of this web application is to provide users with data regarding restaurant hours/closures in their area, how many cases of COVID-19 are in their zip code, and information from their governor and mayor's twitter account. 

# This application was programmed in HTML, CSS, and JavaScript. 

# This application was programmed by Megan Howell, Chloe Rozalsky, Anjali Prabhu, Oceana Covington, and Adena Russel working for LITAS for Girls COVID-19 Projects, led by Anvita Gupta. 
