function changeWebPage() {
	var zipcode = document.getElementById("zip-code").value;
	
	if (zipcode === "02155") {
		window.location.assign("../zip-code-files/02155.html");
	} else if (zipcode === "02909") {
		window.location.assign("../zip-code-files/02909.html");
	} else if (zipcode === "06903") {
		window.location.assign("../zip-code-files/06903.html");
	} else if (zipcode === "08701") {
		window.location.assign("../zip-code-files/08701.html");
	} else if (zipcode === "19120") {
		window.location.assign("../zip-code-files/19120.html");
	} else if (zipcode === "20175") {
		window.location.assign("../zip-code-files/20175.html");
	} else if (zipcode === "21215") {
		window.location.assign("../zip-code-files/21215.html");
	} else if (zipcode === "22434") {
		window.location.assign("../zip-code-files/22434.html");
	} else if (zipcode === "23464") {
		window.location.assign("../zip-code-files/23464.html");
	} else if (zipcode === "30044") {
		window.location.assign("../zip-code-files/30044.html");
	} else if (zipcode === "32301") {
		window.location.assign("../zip-code-files/32301.html");
	} else if (zipcode === "37013") {
		window.location.assign("../zip-code-files/37013.html");
	} else if (zipcode === "45321") {
		window.location.assign("../zip-code-files/45321.html");
	} else if (zipcode === "60625") {
		window.location.assign("../zip-code-files/60625.html");
	} else if (zipcode === "75034") {
		window.location.assign("../zip-code-files/75034.html");
	} else if (zipcode === "84111") {
		window.location.assign("../zip-code-files/84111.html");
	} else if (zipcode === "85027") {
		window.location.assign("../zip-code-files/85027.html");
	} else if (zipcode === "85028") {
		window.location.assign("../zip-code-files/85028.html");
	} else if (zipcode === "85032") {
		window.location.assign("../zip-code-files/85032.html");
	} else if (zipcode === "85254") {
		window.location.assign("../zip-code-files/85254.html");
	} else if (zipcode === "87111") {
		window.location.assign("../zip-code-files/87111.html");
	} else if (zipcode === "87124") {
		window.location.assign("../zip-code-files/87124.html");
	} else if (zipcode === "90011") {
		window.location.assign("../zip-code-files/90011.html");
	} else if (zipcode === "92335") {
		window.location.assign("../zip-code-files/92335.html");
	} else if (zipcode === "94112") {
		window.location.assign("../zip-code-files/94112.html");
	} else if (zipcode === "94538") {
		window.location.assign("../zip-code-files/94538.html");
	} else if (zipcode === "95823") {
		window.location.assign("../zip-code-files/95823.html");
	} else if (zipcode === "96818") {
		window.location.assign("../zip-code-files/96818.html");
	} else if (zipcode === "98115") {
		window.location.assign("../zip-code-files/98115.html");
	} else if (zipcode === "99516") {
		window.location.assign("../zip-code-files/99516.html");
	} else {
		window.location.assign("error.html");
	}
}
